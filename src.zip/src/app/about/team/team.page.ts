import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team',
  templateUrl: './team.page.html',
  styleUrls: ['./team.page.scss'],
  standalone:false
})
export class TeamPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
