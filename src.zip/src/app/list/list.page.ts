import { Component, OnInit } from '@angular/core';


interface Product {
 productName: string,
 productDate: Date,
 productPrice: number,
}


@Component({
  selector: 'app-list',
  templateUrl: './list.page.html',
  styleUrls: ['./list.page.scss'],
  standalone:false
})
export class ListPage implements OnInit {
  today='15 September 2025'
  currentDate = new Date();
  is5daysago=false
  numberclicked=0
  quantity=4
  couponcode:string="0001"
  strvalid:string="Invalid"
  textcolor:string='red'
  discount:number=0
  product:Product = {
   productName: 'Iphone 14',
   productDate: new Date(),
   productPrice: 14000000,
}
books = [
    {
      title: 'To Kill a Mockingbird',
      author: 'Harper Lee',
      publishedDate: new Date('1960-07-11'),
      price: 7.99,
      discount: 10
    },
    {
      title: 'The Great Gatsby',
      author: 'F. Scott Fitzgerald',
      publishedDate: new Date('1925-04-10'),
      price: 10.99,
      discount: 0
    },
    {
      title: 'Pride and Prejudice',
      author: 'Jane Austen',
      publishedDate: new Date('1813-01-28'),
      price: 12.75,
      discount: 15
    }
  ]


checkValid()
{
  if(this.couponcode=='1234')
  {
      this.strvalid='Valid'
      this.discount=5
      this.textcolor='green'
  }
  else if(this.couponcode=='6789')
  {
      this.strvalid='Valid'
      this.discount=10
      this.textcolor='green'
  }
  else
  {
      this.strvalid='Invalid'
      this.discount=0
      this.textcolor='red'
  }
  
}

total():number{
  return this.product.productPrice*this.quantity
}

kurangi()
{
  this.quantity--
}
tambahi()
{
  this.quantity++
}


  today_ind():string {
    const bulans=['Januari','Februari','Maret','April',
                   'Mei','Juni','Juli','Agustus',
                   'September','Oktober','November','Desember'
                  ]
    const haris=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu']

    const d = this.currentDate.getDate();
    const m = this.currentDate.getMonth(); 
    const y = this.currentDate.getFullYear();
    const h = this.currentDate.getDay()
    return haris[h]+', '+d+' '+bulans[m]+' '+y;
  }

  goYesterday(){
    this.currentDate.setDate(this.currentDate.getDate() - 1);
    this.numberclicked++
    if(this.numberclicked==5) this.is5daysago=true
  }

  goTomorrow(){
    this.currentDate.setDate(this.currentDate.getDate() + 1);
    this.numberclicked--;
    this.is5daysago=false
  }

  goToday(){
    this.currentDate=new Date();
    this.numberclicked=0
    this.is5daysago=false

  }

  constructor() { }

  ngOnInit() {
  }

}
