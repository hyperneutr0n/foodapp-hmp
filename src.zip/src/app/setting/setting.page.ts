import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting',
  templateUrl: './setting.page.html',
  styleUrls: ['./setting.page.scss'],
  standalone: false
})
export class SettingPage implements OnInit {

  url:string=''
  password:string=''
  kriteria1:boolean=false
  kriteria2:boolean=false
  kriteria3:boolean=false

  containsDigit(str: string): boolean {
    const regex = /\d/; // Matches any digit (0-9)
    return regex.test(str);
  }

  containsSpecialChars(str: string): boolean {
    const specialCharsRegex = /[!@#$%^&*]/; 
    return specialCharsRegex.test(str);
  }

  cekPassword()
  {
    if(this.password.length>6) this.kriteria1=true; else this.kriteria1=false
    this.kriteria2=this.containsDigit(this.password)
    this.kriteria3=this.containsSpecialChars(this.password)
  }
  constructor() { }

  ngOnInit() {
  }

}
